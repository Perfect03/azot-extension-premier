import type { ServiceConstructor } from "azot";
import type {
  Configuration,
  EME as EMEContract,
  PsshBox,
  RequestFilter,
  ResponseFilter,
} from "./contract.js";

export type * from "./contract.js";

/** The async client exposed by Azot for the EME service module. */
export interface EMEClient {
  /** Configures license servers, advanced options and clear keys. */
  configure(config: Configuration): Promise<void>;
  /** Acquires keys for one media resource. */
  load(initData: string | readonly PsshBox[]): Promise<void>;
  /** Drops the current media and accumulated keys. */
  unload(): Promise<void>;
  /** Returns the keys acquired for the current media. */
  getKeys(): Promise<Awaited<ReturnType<EMEContract["getKeys"]>>>;
  /** Returns statuses for the keys acquired for the current media. */
  getKeyStatuses(): Promise<Awaited<ReturnType<EMEContract["getKeyStatuses"]>>>;
  /** Registers a filter for outgoing license and certificate requests. */
  registerRequestFilter(filter: RequestFilter): Promise<void>;
  /** Registers a filter for incoming license responses. */
  registerResponseFilter(filter: ResponseFilter): Promise<void>;
}

/** Host-provided constructor for the EME service. */
declare const EME: ServiceConstructor<EMEClient>;

export { EME };
