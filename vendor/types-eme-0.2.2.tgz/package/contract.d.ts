/**
 * Represents a Protection System Specific Header box as used by ISOBMFF Common Encryption. Contains
 * DRM system-specific data that can be used to obtain a decryption key.
 *
 * @group Miscellaneous
 * @public
 */
export type PsshBox = {
    /**
     * The system ID as lowercase hex (UUID dashes optional): Widevine
     * `edef8ba9-79d6-4ace-a3c8-27dcd51d21ed`, PlayReady `9a04f079-9840-4286-ab92-e65be0885f95`,
     * ClearKey `1077efec-c0b2-4d02-ace3-3c1e52e2fb4b`.
     */
    systemId: string;
    /**
     * The list of key IDs (32-character lowercase hex strings) this box applies to, or `null` if it applies to all key IDs.
     */
    keyIds: string[] | null;
    /** The content protection system-specific data. */
    data: Uint8Array;
};
/**
 * The key systems the service licenses for. ClearKey is served from `clearKeys` or its license
 * server. The rest run against the engine configured in extension settings: imported WVD credentials
 * serve Widevine, PRD credentials serve PlayReady, a remote endpoint serves what it implements.
 * Both PlayReady spellings name the same key system.
 */
export type KeySystem = "com.widevine.alpha" | "com.microsoft.playready" | "com.microsoft.playready.recommendation" | "org.w3.clearkey";
/** A key ID or key as 32 lowercase hexadecimal characters, without separators. */
export type MediaKeyId = string;
export type MediaKey = string;
/** The `MediaKeyStatusMap` vocabulary. */
export type MediaKeyStatus = "usable" | "usable-in-future" | "expired" | "released" | "output-restricted" | "output-downscaled" | "status-pending" | "internal-error";
/** What a filter is asked to transform: one license exchange or a server certificate fetch. */
export type RequestType = "license" | "server-certificate";
/**
 * Rewrites one outgoing request before it is sent. Return the replacement, or nothing to keep
 * the request as-is. Filters run in registration order, each seeing the previous one's output.
 */
export type RequestFilter = (type: RequestType, request: Request) => Request | void | Promise<Request | void>;
/** Rewrites one incoming response before its body reaches the engine. Return the replacement
 * response, or nothing to keep the response as-is. A replacement must carry the license bytes
 * the engine expects.
 */
export type ResponseFilter = (type: RequestType, response: Response) => Response | void | Promise<Response | void>;
/** Per-key-system extras, like shaka's `drm.advanced` entry. */
export type AdvancedConfiguration = {
    /** Sent on every request to this key system's server. Filters can add more per request. */
    readonly headers?: Readonly<Record<string, string>>;
    /** Privacy mode (Widevine only). Sent to the engine before the exchange. */
    readonly serverCertificate?: Uint8Array;
    /** Privacy mode from a URL: fetched once per URI through the filters. */
    readonly serverCertificateUri?: string;
};
/**
 * The service configuration, shaped like shaka's `drm` config so its documentation applies:
 * https://shaka-project.github.io/shaka-player/docs/api/tutorial-drm-config.html
 */
export type Configuration = {
    /** License server URLs by key system. Requests go to the URL of the key system being licensed. */
    readonly servers?: Readonly<Partial<Record<KeySystem, string>>>;
    readonly advanced?: Readonly<Partial<Record<KeySystem, AdvancedConfiguration>>>;
    /**
     * Content keys by key ID, both as 32 lowercase hex characters. When they cover every key ID
     * the init data names, `load()` serves them locally: no engine, no network.
     */
    readonly clearKeys?: Readonly<Record<MediaKeyId, MediaKey>>;
};
/**
 * A key service shaped like shaka-player's DRM stack: `configure()` names servers and keys,
 * `load()` runs one acquisition per media, filters reshape its HTTP traffic. Which engine the
 * exchange runs against comes from extension settings (a remote endpoint or imported client
 * credentials), not from configuration.
 *
 * The package publishes it as a constructor under the `EME` service module: declare `"eme"` in
 * `peerDependencies`, then `import { EME } from "eme"` and `await using service = new EME()`.
 */
export interface EME {
    /**
     * Merges configuration, like `shaka.Player#configure()`: the entries given override the stored
     * ones, `advanced` merges per field and `headers` per header. Applies to `load()` calls that
     * start afterwards, never to one already running.
     *
     * https://shaka-project.github.io/shaka-player/docs/api/shaka.Player.html#configure
     */
    configure(config: Configuration): void;
    /**
     * Acquires the keys for one media's init data: a full PSSH box sequence as base64, or the boxes
     * themselves. Resolves once keys arrived; they accumulate in `getKeys()` over calls. To license
     * by bare key ID, pass a version 1 box: `{ systemId, keyIds, data: new Uint8Array() }`.
     *
     * The key system comes from the init data and the engine. When `clearKeys` covers every key ID
     * the init data names, the keys are served locally with no engine and no network. Init data
     * declaring ClearKey licenses against `servers["org.w3.clearkey"]` with the JSON license
     * protocol. Anything else runs against the configured engine, which decides the key system and
     * has the init data converted to it as needed.
     *
     * Rejects with `SERVICE_UNAVAILABLE` when configuration is missing (no license server for the
     * key system, no configured engine) and `KEY_UNAVAILABLE` when the exchange produces no keys.
     */
    load(initData: string | readonly PsshBox[]): Promise<void>;
    /**
     * Drops the current media, like `shaka.Player#unload()`: aborts in-flight acquisitions, closes
     * their sessions, and clears the accumulated keys and statuses. Configuration (servers,
     * advanced, clearKeys, filters) stays, so the instance is ready for the next `load()`.
     *
     * https://shaka-project.github.io/shaka-player/docs/api/shaka.Player.html#unload
     */
    unload(): Promise<void>;
    /** Key ID to the current key status, in `MediaKeyStatusMap` terms. */
    getKeyStatuses(): Record<MediaKeyId, MediaKeyStatus>;
    /** Key ID to content key. Transient: never log, persist or export the values. */
    getKeys(): Record<MediaKeyId, MediaKey>;
    /**
     * Transforms outgoing traffic: every license exchange and server certificate fetch. Return the
     * replacement request or nothing to keep it.
     *
     * https://shaka-project.github.io/shaka-player/docs/api/tutorial-license-wrapping.html
     */
    registerRequestFilter(filter: RequestFilter): void;
    /** Transforms incoming traffic with the same contract, before the license reaches the engine. */
    registerResponseFilter(filter: ResponseFilter): void;
}
